---
layout: post
title: "Max Goldhouse, Laid back European, Launches Site"
date: 2016-06-22
---

Well. Finally got around to putting this old website together. Neat thing about it - powered by [Jekyll](http://jekyllrb.com) and I can use Markdown to author my posts. It actually is a lot easier than I thought it was going to be.
